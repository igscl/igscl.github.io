# Portfolio Documentation
## URL:
### https://igscl.github.io/
## Repository:
### https://github.com/igscl/igscl.github.io

## Description:

### Purpose:
The purpose of my website is to reflect a little bit of who I am while giving all the information needed to get in touch with me, providing a simple and minimalistic interface.

### Functionality and features

The site opens up